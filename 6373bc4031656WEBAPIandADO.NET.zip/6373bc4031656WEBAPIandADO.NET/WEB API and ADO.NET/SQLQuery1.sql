use [master]


--Parent table
CREATE TABLE USERS(
id_user INT PRIMARY KEY IDENTITY(1,1),
name_user VARCHAR(30) NOT NULL,
);

--Child table 
CREATE TABLE BOOKS (
id_book INT PRIMARY KEY IDENTITY(1,1),
name_book VARCHAR(30) NOT NULL,
price_book FLOAT NOT NULL,
id_user INT CONSTRAINT  user_fk FOREIGN KEY REFERENCES USERS(id_user)
);

--Populating USERS
INSERT INTO USERS
VALUES 
('Huzaifa'),
('Waseem'),
('Muzammil'),
('Aamir'),
('Ramish'),
('Iqbal'),
('Furqan'),
('Faheem'),
('Wasif'),
('Haseeb');

----Populating BOOKS
INSERT INTO BOOKS 
VALUES 
('BOOK1',100,1),
('BOOK2',200,1),
('BOOK3',300,2),
('BOOK4',400,2),
('BOOK5',500,3),
('BOOK6',600,NULL),
('BOOK7',700,NULL),
('BOOK8',800,NULL),
('BOOK9',900,NULL);

--Adding two columns in BOOKS
ALTER TABLE BOOKS ADD issueDate DATE, returnDate DATE;

UPDATE BOOKS 
SET issueDate='2022-10-13', id_user=1 
WHERE id_book=1;

UPDATE BOOKS 
SET issueDate='2022-10-17', id_user=1 
WHERE id_book=2;

UPDATE BOOKS 
SET issueDate='2022-11-16', id_user=2 
WHERE id_book=3;

UPDATE BOOKS 
SET issueDate='2022-9-20', id_user=2 
WHERE id_book=4;

UPDATE BOOKS 
SET issueDate='2022-7-25', id_user=2 
WHERE id_book=5;


SELECT * FROM BOOKS;
SELECT * FROM USERS;
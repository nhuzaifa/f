
use [master]

--Task 1
CREATE PROCEDURE sp_AddBook

@name_book VARCHAR(30),
@price_book FLOAT
AS
BEGIN
INSERT INTO BOOKS(name_book,price_book)
VALUES
(@name_book, @price_book )
END

--execute sp_AddBook 'ff',45

--Task 2
CREATE PROCEDURE sp_AddSt
@name_user VARCHAR(30)
AS
BEGIN
INSERT INTO USERS
VALUES
(@name_user);
END
--sp_AddSt 'efefg'

--Task 3
CREATE PROCEDURE sp_GetBookDetails
@name_book VARCHAR(30)
AS
BEGIN
SELECT * FROM BOOKS WHERE name_book=@name_book;
END
--sp_GetBookDetail 3

--Task 4
CREATE PROCEDURE sp_GetUser
@id_user INT
AS
BEGIN
SELECT * FROM USERS WHERE id_user=@id_user
SELECT * FROM BOOKS WHERE id_user=@id_user;
END
---sp_GetStDetail 1


--Task 5
CREATE PROCEDURE sp_UpdateBook
@id_book INT,
@name_book VARCHAR(30),
@price_book FLOAT
AS
BEGIN
UPDATE BOOKS
SET name_book=@name_book, price_book=@price_book
WHERE id_book=@id_book
END
--sp_UpdateBook 4, 'dfhhfghfgh',56.7

--Task 6
CREATE PROCEDURE sp_UpdateUser
@id_user INT,
@name_user VARCHAR(30)
AS
BEGIN
UPDATE USERS
SET name_user=@name_user
WHERE id_user=@id_user
END
--sp_UpdateSt 2, 'hdkjadkjkdjk'

--Task 7
CREATE PROCEDURE sp_IssueBook

@id_book INT,
@id_user INT
AS
BEGIN
IF EXISTS (SELECT * FROM BOOKS WHERE id_book=@id_book AND id_user is NULL)
BEGIN
UPDATE BOOKS SET id_user=@id_user WHERE id_book=@id_book;
END
END


--EXECUTE sp_IssueBook 2,1

--Task 8
CREATE PROCEDURE sp_RemoveBook

@id_book VARCHAR(30)
AS
BEGIN

DELETE FROM BOOKS WHERE id_book = @id_book;

END

--Task 9
CREATE PROCEDURE sp_RemoveUser
@id_user INT
AS
BEGIN

IF NOT EXISTS (select * from BOOKS WHERE id_user=@id_user)
BEGIN
DELETE USERS WHERE id_user =  @id_user
END
END

--Task 10
CREATE PROCEDURE sp_ReturnBook
@id_book INT
AS
BEGIN
 UPDATE BOOKS SET id_user = NULL  WHERE id_book=@id_book
END

--Task 11
CREATE PROCEDURE sp_IssueDate
@id_book INT
AS
BEGIN
SELECT issueDate FROM BOOKS WHERE id_book = @id_book
END

-------------------------
CREATE PROCEDURE sp_GetAllBooks
AS
BEGIN
SELECT * FROM BOOKS
END

--GetAllUsers
CREATE PROCEDURE sp_GetAllUsers
AS
BEGIN
SELECT * FROM USERS
END
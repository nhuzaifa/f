﻿
using System;
using System.Collections.Generic;
using WebApplication5.Models;

namespace WebApplication5.Business_Layer
{
    public interface ILibrary_System
    {
        public Book_Class Get_book(string name);
        public void AddBook(Book_Class book);
        public void AddUser(User_Class user);
        public User_Class GetUser(int id);
        public Book_Class UpdateBook(Book_Class updatedBook);
        public User_Class UpdateUser(User_Class updatedUser);
        public void IssueBook(int userID, Book_Class updatedBook);
        public void DeleteBook(string bookName);
        public void DeleteUser(int userId);
        public void ReturnBook(int bookId);
        public List<User_Class> GetAllUser();
        public List<Book_Class> GetAllBook();
        public string CalculateFine(int bookId, DateTime inputDate);

    }
}

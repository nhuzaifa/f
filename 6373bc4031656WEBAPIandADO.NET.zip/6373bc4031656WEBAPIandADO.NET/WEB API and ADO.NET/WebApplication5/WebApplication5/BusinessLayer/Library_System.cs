﻿
using WebApplication5.DataAccessLayer;
using WebApplication5.Models;
using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5.Business_Layer;

namespace WebApplication5.Business_Layer
{
    public class Library_System : ILibrary_System
    {
        ISQLDataHelper _SQADataHelper;

        public Library_System(ISQLDataHelper _SQADataHelper)
        {
            this._SQADataHelper = _SQADataHelper;
        }
        public Book_Class Get_book(string name)
        {
            return _SQADataHelper.GetBook(name);
        }
        public void AddBook(Book_Class book)
        {
            _SQADataHelper.AddBook(book);

        }
        public void AddUser(User_Class user)
        {
            _SQADataHelper.AddUser(user);

        }
        public User_Class GetUser(int id)
        {
            return _SQADataHelper.GetUser(id);
        }
        public Book_Class UpdateBook(Book_Class updatedBook)
        {
            return _SQADataHelper.UpdateBook(updatedBook);
        }
        public User_Class UpdateUser(User_Class updatedUser)
        {
            return _SQADataHelper.UpdateUser(updatedUser);
        }
        public void IssueBook(int userID, Book_Class updatedBook)
        {
            _SQADataHelper.IssueBook(userID, updatedBook);
        }
        public void DeleteBook(string bookName)
        {
            _SQADataHelper.DeleteBook(bookName);
        }
        public void DeleteUser(int userId)
        {
            _SQADataHelper.DeleteUser(userId);
        }
        public void ReturnBook(int bookId)
        {
            _SQADataHelper.ReturnBook(bookId);
        }
        public List<User_Class> GetAllUser()
        {
            return _SQADataHelper.GetAllUser();
        }
        public List<Book_Class> GetAllBook()
        {
            return _SQADataHelper.GetAllBook();
        }
        public string CalculateFine(int bookId, DateTime inputDate)
        {
            DateTime checkDate = inputDate;
            DateTime issuedate = _SQADataHelper.getIssueDate(bookId);
            int count = 0;
            for (DateTime i = issuedate; i <= checkDate; i = i.AddDays(1))
            {

                if (i.ToString("dddd") == "Sunday" || i.ToString("dddd") == "Saturday")
                {
                    continue;
                }
                count++;
            }

            
            Console.WriteLine(count);
            if (count - 15 > 0)
            {
                return "The fine on user is Rs: " + (count - 15);
            }
            else
            {
                return "No fine imposed on the user";

            }
        }
    }
}


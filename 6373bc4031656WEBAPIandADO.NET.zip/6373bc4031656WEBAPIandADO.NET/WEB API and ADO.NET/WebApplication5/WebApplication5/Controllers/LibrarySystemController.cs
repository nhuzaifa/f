﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication5.Business_Layer;
using System;
using System.Collections.Generic;
using WebApplication5.Models;
using WebApplication5.DataAccessLayer;

namespace WebApplication5.Controllers
{
    [Route("Librarysystem")]
    [ApiController]
    public class LibrarySystemController : ControllerBase
    {
        ILibrary_System Library;
        public LibrarySystemController(ILibrary_System Library)
        {
            this.Library = Library;
        }

        //Task 3: Write an API that fetches a detail of a book
        [HttpGet("getbookdetail/{name}")]
        public IActionResult getbookdetail(string name)
        {
            Book_Class onebook = Library.Get_book(name);

            if (onebook.name == null)
            {
                return NotFound("Book name cannot be found");
            }
            else
            {
                return Ok(new { comment = "The book is in the library", onebook });
            }
        }

        //Task 1:  Write an endpoint to add a new book to the repository
        [HttpPost("addbook")]
        public List<Book_Class> addbook([FromBody] Book_Class newbook)
        {
            Library.AddBook(newbook);
            return Library.GetAllBook();
        }

        //Task 2: Write an endpoint to add a new user to the users List 
        [HttpPost("adduser")]
        public List<User_Class> adduser([FromBody] User_Class newuser)
        {
            Library.AddUser(newuser);
            return Library.GetAllUser();
        }

        //Task 4: Write an API that fetches a detail of a user
        [HttpGet("getuserdetail/{id}")]
        public IActionResult getuserdetail(int id)
        {
            User_Class oneuser = Library.GetUser(id);
            return Ok(new { comment = "The user detail is below", oneuser });
        }

        //Task 5: Another endpoint is required to update the book record
        [HttpPut("updatebook/{id}")]
        public IActionResult updatebook(int id, [FromBody] Book_Class updatedBook)
        {
            updatedBook.id = id;
            Book_Class upbook = Library.UpdateBook(updatedBook);
            return Ok(new { comment = "The book has been updated", upbook });
        }

        //Task 6: An endpoint is required to update the user record
        [HttpPut("updateuser/{id}")]
        public IActionResult updateuser(int id, [FromBody] User_Class updatedUser)
        {
            updatedUser.id = id;
            User_Class upuser = Library.UpdateUser(updatedUser);
            return Ok(new { comment = "The user has been updated", upuser });
        }

        //Task 7: If a user issues a new book, we need to add it to the database
        [HttpPut("issuebook/{userId}")]
        public IActionResult issuebook(int userId, [FromBody] Book_Class issuedBook)
        {           
            Library.IssueBook(userId, issuedBook);
            return Ok("The book has been issued to the user");
        }

        //Task 8: Write endpoint to remove a book from the repository
        [HttpDelete("deletebook/{bookName}")]
        public IActionResult deletebook(string bookName)
        {
            Library.DeleteBook(bookName);
            return Ok("The book has been deleted");
        }

        //Task 9: Write an API that remove the user from the system
        [HttpDelete("deleteuser/{userId}")]
        public IActionResult deleteuser(int userId)
        {          
            Library.DeleteUser(userId);
            return Ok("The user has been deleted");
        }

        //Task 10: Write an API for the returning of issued book by the user.
        [HttpPut("returnbook/{bookId}")]
        public IActionResult returnbook(int bookId)
        {
            Library.ReturnBook(bookId);
            return Ok("The book has been returned by the user");
        }

        //Task 11: Add an API endpoint to calculate the fine imposed on the user
        [HttpPut("fine/{bookId}")]
        public string calculatefine(int bookId, [FromBody] CheckDateInput inputDate)
        {
            //input "checkDate" as key in JSON Body
            DateTime date = Convert.ToDateTime(inputDate.checkDate);
            return Library.CalculateFine(bookId, date);
        }

    }
}

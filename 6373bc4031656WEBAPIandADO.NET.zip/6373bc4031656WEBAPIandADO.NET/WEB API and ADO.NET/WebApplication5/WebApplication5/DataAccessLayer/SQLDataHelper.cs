﻿using Microsoft.Extensions.Configuration;
using WebApplication5.Models;
using System.Data.SqlClient;
using System.Data;
using System;
using System.Collections.Generic;
using System.Net;

namespace WebApplication5.DataAccessLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        string connectionString = "";
        public SQLDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("projectDB");
        }
        //Task 3
        public Book_Class GetBook(string name)
        {
            Book_Class mybook = new Book_Class();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBookDetails", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = name;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    mybook.id = Convert.ToInt32(sdr["id_book"]);
                    mybook.name = sdr["name_book"].ToString();
                    mybook.price = Convert.ToInt32(sdr["price_book"]);

                }
                con.Close();
            }
            return mybook;

        }
        //Task 1
        // ADD book in the library books
        public void AddBook(Book_Class book)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddBook", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = book.name;
                cmd.Parameters.Add("@price_book", SqlDbType.Int).Value = book.price;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        //Task 2
        //add user to the db
        public void AddUser(User_Class user)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddSt", con);

                cmd.Parameters.Add("@name_user", SqlDbType.VarChar).Value = user.name;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        //Task 4
        //Get user detail
        public User_Class GetUser(int id)
        {
            User_Class myuser = new User_Class();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetUser", con);

                cmd.Parameters.Add("@id_user", SqlDbType.VarChar).Value = id;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {                  
                    myuser.id = Convert.ToInt32(sdr["id_user"]);
                    myuser.name = sdr["name_user"].ToString();                  

                }
                sdr.NextResult();
                List<Book_Class> mybooks = new List<Book_Class>();

                while (sdr.Read())
                {
                    Book_Class book = new Book_Class();
                    book.name = sdr["name_book"].ToString();
                    book.price = Convert.ToInt32(sdr["price_book"]);
                    book.id = Convert.ToInt32(sdr["id_book"]);
                    mybooks.Add(book);
                }
                myuser.userbooks = mybooks;
                con.Close();
            }
            return myuser;


        }
        //Task 5
        //update book
        public Book_Class UpdateBook(Book_Class updatedBook)
        {         
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateBook", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = updatedBook.name;
                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = updatedBook.id;
                cmd.Parameters.Add("@price_book", SqlDbType.Int).Value = updatedBook.price;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

            return updatedBook;
        }

        //Task 6
        //update book
        public User_Class UpdateUser(User_Class updatedUser)
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateUser", con);

                cmd.Parameters.Add("@name_user", SqlDbType.VarChar).Value = updatedUser.name;
                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = updatedUser.id;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

            return updatedUser;
        }

        //Task 7
        public void IssueBook(int userID, Book_Class issuedBook)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_IssueBook", con);


                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = userID;
                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = issuedBook.id;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        //Task 8
        public void DeleteBook(string bookName)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveBook", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = bookName;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        //Task 9
        public void DeleteUser(int userId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveUser", con);

                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = userId;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }

        //Task 10
        public void ReturnBook(int bookId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_ReturnBook", con);

                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = bookId;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        public List<User_Class> GetAllUser()
        {
            List<User_Class> allUser = new List<User_Class>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllUsers", con);

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    User_Class oneUser = new User_Class();
                    oneUser.id = Convert.ToInt32(sdr["id_user"]);
                    oneUser.name = sdr["name_user"].ToString();
                    List<Book_Class> allBooks = new List<Book_Class>();
                 
                    oneUser.userbooks = allBooks;
                    allUser.Add(oneUser);
                }
                con.Close();
            }
            return allUser;

        }

        public List<Book_Class> GetAllBook()
        {
            List<Book_Class> allBooks = new List<Book_Class>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllBooks", con);

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {

                    Book_Class book = new Book_Class();
                    book.name = sdr["name_book"].ToString();
                    book.price = Convert.ToInt32(sdr["price_book"]);
                    book.id = Convert.ToInt32(sdr["id_book"]);
                    allBooks.Add(book);

                }


                con.Close();
            }
            return allBooks;


        }
    
        //Task 11
    public DateTime getIssueDate(int bookId)
        {
            DateTime issueDate = new DateTime();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_IssueDate", con);

                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = bookId;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    issueDate = Convert.ToDateTime(sdr["issueDate"].ToString());
                }
                con.Close();

            }
            return issueDate;

        }
    }
}

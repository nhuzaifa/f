﻿namespace WebApplication5.Models
{
    public class Book_Class
    {
        public int id { get; set; }
        public string? name { get; set; }
        public int? price { get; set; }
    }
}
﻿namespace WebApplication5.Models
{
    public class CheckDateInput
    {
        public string checkDate { get; set; }
    }
}

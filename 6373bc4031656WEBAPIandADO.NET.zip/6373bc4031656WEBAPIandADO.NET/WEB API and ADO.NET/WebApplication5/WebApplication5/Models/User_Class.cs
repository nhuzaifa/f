﻿
using System.Collections.Generic;

namespace WebApplication5.Models
{
    public class User_Class
    {
        public string name { get; set; }
        public int? id { get; set; }

        public List<Book_Class> userbooks { get; set; }

    }

}